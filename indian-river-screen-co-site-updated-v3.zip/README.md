# Indian River Screen Co. Website

Static website for IndianRiverScreenCo.com.

Files:
- index.html — website
- CNAME — custom domain
- assets/ — optimized website photos

Phone: 772-672-9857
Email: indianriverscreen@gmail.com
